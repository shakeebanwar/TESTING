﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data.OleDb;


namespace kashif
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        OracleConnection con = new OracleConnection("DATA SOURCE=localhost:1521/xe;USER ID=SAMIK; PASSWORD=12345");
        private void view1()
        {
            con.Open();
            OracleDataAdapter dr = new OracleDataAdapter("SELECT * FROM DRIVER", con);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            con.Close();

        }
        private void view2()
        {
            con.Open();
            OracleDataAdapter dr = new OracleDataAdapter("SELECT * FROM CAR", con);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            con.Close();

        }
        private void view3(){
        
            con.Open();
            OracleDataAdapter dr = new OracleDataAdapter("SELECT * FROM CUSTOMER", con);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            con.Close();

        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            view1();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            view2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            view3();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
