﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data.OleDb;

namespace sami_oracle
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        OracleConnection con = new OracleConnection("DATA SOURCE=localhost:1521/xe;USER ID=SAMI; PASSWORD=12345");
     
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
       
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OracleDataAdapter da= new OracleDataAdapter("SELECT * FROM  admin_login WHERE name='" + textBox1.Text + "'and password='" + textBox2.Text + "'", con);
            con.Open();

            DataTable d = new DataTable();
     
            da.Fill(d);




            if (d.Rows.Count == 1)
            {

                Form2 m = new Form2();
                this.Hide();
                m.Show();

            }
            else
            {
                MessageBox.Show("login not sucessfully");
            }
            con.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
