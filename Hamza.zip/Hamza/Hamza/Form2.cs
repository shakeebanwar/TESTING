﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data.OleDb;

namespace Hamza
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        OracleConnection con = new OracleConnection("DATA SOURCE=localhost:1521/xe;USER ID=SAMIH; PASSWORD=12345");
        private void view()
        {
            con.Open();
            OracleDataAdapter dr = new OracleDataAdapter("SELECT * FROM customer", con);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            con.Close();

        }
        private void view1()
        {
            con.Open();
            OracleDataAdapter dr = new OracleDataAdapter("SELECT * FROM product", con);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            con.Close();

        }
        private void view2()
        {
            con.Open();
            OracleDataAdapter dr = new OracleDataAdapter("SELECT * FROM employee", con);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            con.Close();

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            view();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            view1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            view2();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
