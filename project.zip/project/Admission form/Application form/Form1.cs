﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Application_form
{
    public partial class Form1 : Form
    {
      
        public Form1()
        {
            InitializeComponent();
        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                    Form2 r = new Form2();
                    this.Hide();
                    r.Show();
                    string Program = "unchecked";
                    if (radioButton1.Checked)
                    {
                        Program = "BS";
                    }
                    else if (radioButton2.Checked)
                    {
                        Program = "MS";
                    }
                    else if (radioButton3.Checked)
                    {

                        Program = "Phd";
                    }
                    r.richTextBox1.Text = "Name: " + textBox1.Text + Environment.NewLine + "F.Name: " + textBox2.Text + Environment.NewLine + "Age: " + numericUpDown1.Value + Environment.NewLine + "city: " + textBox3.Text + Environment.NewLine + "programs: " + Program + Environment.NewLine + "Academic record: ";
                    foreach (string s in checkedListBox1.CheckedItems)
                    {
                        r.richTextBox1.Text += "\n" + s;

                    }
                
            }
        

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
