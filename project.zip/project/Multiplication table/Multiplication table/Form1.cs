﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Multiplication_table
{
    public partial class Form1 : Form
    {
        public static int tb;
        public static int str;
        public static int end;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tb = Convert.ToInt32(textBox1.Text);
            str = Convert.ToInt32(textBox2.Text);
            end = Convert.ToInt32(textBox3.Text);
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Multiplication table";
             int table = Form1.tb;
           int start = Form1.str;
           int end = Form1.end;
           
           for (int i =start; i <= end; i++)
           {
               listBox1.Items.Add(table + "*" + i + "=" + (table * i));  
               
           }

        }
        }
    }
