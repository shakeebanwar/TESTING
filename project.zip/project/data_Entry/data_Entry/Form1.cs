﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace data_Entry
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=DATAENTRY;Integrated Security=True");
           
            SqlCommand cmd = new SqlCommand("SELECT * FROM  LOGIN WHERE USER_NAME='"+textBox1.Text+"'and password='"+textBox2.Text+"'",con);
            con.Open();
            //cmd.ExecuteNonQuery();
            DataTable d = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(d);
            // int count = 0;
             //count = Convert.ToInt32(d.Rows.ToString());
            

            
            if(d.Rows.Count==1){

                Form2 f = new Form2();
                this.Hide();
                f.Show();
                 MessageBox.Show("login sucessfully");
            }
            else
            {
                MessageBox.Show("login not sucessfully");
            }
            con.Close();
        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
