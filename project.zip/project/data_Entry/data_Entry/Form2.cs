﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;



namespace data_Entry
{
    public partial class Form2 : Form
    {
  
        public Form2()
        {
            InitializeComponent();
        }
        public int id;
        public string name;
        public string cla;
        public string age;

        private void view()
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=DATAENTRY;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from information", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=DATAENTRY;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("insert into INFORMATION values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("record insert");
            con.Close();
            view();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            view();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (id > 0)
            {

                SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=DATAENTRY;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Delete from information where id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record delete");
                view();
            }
            else
            {
                MessageBox.Show("select row first");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            DataTable D = new DataTable();
            D.Columns.Add("NAME", typeof(string));
            D.Columns.Add("class", typeof(string));
            D.Columns.Add("AGE", typeof(string));
            D.Columns.Add("ID", typeof(string));
            dataGridView1.DataSource = D;

        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {



        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value.ToString());
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {



            SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=DATAENTRY;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("update information set name='" + textBox1.Text + "' , class='" + textBox2.Text + "' , age='" + textBox3.Text + "' where id=@id", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", this.id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record update");
            view();





        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=DATAENTRY;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select name,class,age from information where id=" + textBox4.Text, con);
              // DataTable dt = new DataTable();
          
                if (con.State != ConnectionState.Open)
                
                          

                    con.Open();

                    SqlDataReader dr = cmd.ExecuteReader();
                    dr.Read();

                    
                    
                    if (dr.HasRows)
                    {

                        textBox1.Text = dr[0].ToString();
                        textBox2.Text = dr[1].ToString();
                        textBox3.Text = dr[2].ToString();
                       
                    }
                    else
                    {

                        MessageBox.Show("this id doesnot exist");
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";

                    }


               


                    //D.Load(dr);
                    //dataGridView1.DataSource = D;


                //dataGridView1.SelectedRows[0].Cells[0].Value = textBox1.Text;
                //dataGridView1.SelectedRows[0].Cells[1].Value = textBox2.Text;
                //dataGridView1.SelectedRows[0].Cells[2].Value = textBox3.Text;
                //dataGridView1.SelectedRows[0].Cells[3].Value = textBox4.Text;
               con.Close();

             
                }
            
            catch (Exception ex)
            {
               
                MessageBox.Show(ex.Message);
            }
        }
    }
    }

