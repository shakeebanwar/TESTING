﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace filing
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string path1 = comboBox1.Text + comboBox2.Text + "\\" + textBox1.Text;
            if (File.Exists(path1))
            {
                StreamWriter strm = new StreamWriter(path1);
                strm.Write(richTextBox1.Text);
                strm.Close();
                MessageBox.Show("Text has been Written");
            }
            else
            {
                MessageBox.Show("File Not Found");
            }
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Visible = true;
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            DriveInfo[] list = DriveInfo.GetDrives();
            foreach (DriveInfo di in list)
                comboBox1.Items.Add(di.Name);
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dif = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] df = dif.GetDirectories();
            foreach (DirectoryInfo d in df)
            {
                comboBox2.Items.Add(d.ToString());
            }
        }
    }
}
