﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace filing
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string path = comboBox1.Text +comboBox2.Text+ "\\"+textBox1.Text +"."+ textBox2.Text;
            if (!File.Exists(path))
            {
                File.Create(path);
                MessageBox.Show("File Created");
            }
            else
            {
                MessageBox.Show("Already Exist");
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            DriveInfo[] list = DriveInfo.GetDrives();
            foreach (DriveInfo di in list)
                comboBox1.Items.Add(di.Name);
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dif = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] df = dif.GetDirectories();
            foreach (DirectoryInfo d in df)
            {
                comboBox2.Items.Add(d.ToString());
            }
        }
    }
}
