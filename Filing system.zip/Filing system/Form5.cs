﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Filing_system
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            DriveInfo[] df = DriveInfo.GetDrives();
            foreach (DriveInfo d in df)
            {
                comboBox1.Items.Add(d.Name);
            }
        }
        public string path;

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] dl = di.GetDirectories();
            foreach (DirectoryInfo d in dl)
            {
                comboBox2.Items.Add(d.Name);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            path = comboBox1.Text + comboBox2.Text + "\\" + comboBox3.Text;

            DirectoryInfo df = new DirectoryInfo(path);
            FileInfo[] fi = df.GetFiles();
            foreach(FileInfo f in fi)
            {
                comboBox3.Items.Add(f.Name);
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string path1 = comboBox1.Text + comboBox2.Text + "\\" + comboBox3.Text;

            if (File.Exists(path1))
            {
                StreamReader st = new StreamReader(path1);
                richTextBox1.Text = st.ReadToEnd();
                st.Close();
                MessageBox.Show("File his read");
            }
            else
            {
                MessageBox.Show("file Is not exist");
            }

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
