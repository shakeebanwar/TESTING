﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Filing_system
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            Form1 f2 = new Form1();
            this.Hide();
            f2.Show();

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            DriveInfo[] df = DriveInfo.GetDrives();
            foreach(DriveInfo n in df)
            {
                comboBox1.Items.Add(n.Name);
            }


        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string path = comboBox1.Text + "//" + txtname.Text;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
                MessageBox.Show("Directer has been created");
            }
            else
            {
                MessageBox.Show("Directer Already exits");
            }
        }
    }
}
