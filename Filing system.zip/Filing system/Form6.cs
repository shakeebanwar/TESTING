﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Filing_system
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            DriveInfo[] dr = DriveInfo.GetDrives();
            foreach(DriveInfo d in dr)
            {
                comboBox1.Items.Add(d.Name);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string path = comboBox1.Text + comboBox2.Text + "\\" + comboBox3.Text;
            DirectoryInfo dr = new DirectoryInfo(path);
            FileInfo[] fl = dr.GetFiles();
            foreach(FileInfo f in fl)
            {
                comboBox3.Items.Add(f.Name);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dr = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] dd = dr.GetDirectories();
            foreach(DirectoryInfo d in dd)
            {
                comboBox2.Items.Add(d.Name);
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string path = comboBox1.Text + comboBox2.Text + "\\" + comboBox3.Text;
            if (File.Exists(path))
            {
                StreamWriter str = new StreamWriter(path);
                str.Write(richTextBox1.Text);
                str.Close();
                MessageBox.Show("the file is written");
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
