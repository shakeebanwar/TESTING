﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Filing_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Form6 f2 = new Form6();
            this.Hide();
            f2.Show();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Hide();
            f2.Show();
        }

        private void file(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Form3 f2 = new Form3();
            this.Hide();
            f2.Show();

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Form4 f2 = new Form4();
            this.Hide();
            f2.Show();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Form5 f2 = new Form5();
            this.Hide();
            f2.Show();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

            Form7 f1 = new Form7();
            f1.Show();
            this.Hide();
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {

            Form8 f1 = new Form8();
            f1.Show();
            this.Hide();
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            Form9 f1 = new Form9();
            f1.Show();
            this.Hide();
        }
    }
}
