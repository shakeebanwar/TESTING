﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Filing_system
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            DriveInfo[] df = DriveInfo.GetDrives();
            foreach (DriveInfo d in df)
            {
                comboBox1.Items.Add(d.Name);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] dl = di.GetDirectories();
            foreach (DirectoryInfo d in dl)
            {
                comboBox2.Items.Add(d.Name);
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string path = comboBox1.Text + comboBox2.Text + "\\" + txtname.Text + "." + txttype.Text;
            if (!File.Exists(path))
            {
                File.Create(path);
                MessageBox.Show("File has been Created");
            }
            else
            {
                MessageBox.Show("File has Already Exists");
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            Form1 f2 = new Form1();
            this.Hide();
            f2.Show();
        }
    }
}
