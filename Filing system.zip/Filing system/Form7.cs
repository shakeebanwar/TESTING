﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Filing_system
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            DriveInfo[] d = DriveInfo.GetDrives();
            foreach(DriveInfo df in d)
            {
                comboBox1.Items.Add(df.Name);
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string path = comboBox1.Text + comboBox2.Text + "\\" + comboBox3.Text;
            if (File.Exists(path))
            {
                File.Delete(path);
                MessageBox.Show("File has been Deleted");

            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string path = comboBox1.Text + comboBox2.Text + "\\" + comboBox3.Text;
            DirectoryInfo dt = new DirectoryInfo(path);
            FileInfo[] fl = dt.GetFiles();
            foreach(FileInfo f in fl)
            {
                comboBox3.Items.Add(f.Name);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] dt = di.GetDirectories();
            foreach(DirectoryInfo d in dt)
            {
                comboBox2.Items.Add(d.Name);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
