﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Filing_system
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            DriveInfo[] df = DriveInfo.GetDrives();
            foreach(DriveInfo d  in df)
            {
                comboBox1.Items.Add(d.Name);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(comboBox1.Text);
            DirectoryInfo[] dl = di.GetDirectories();
            foreach(DirectoryInfo d in dl)
            {
                comboBox2.Items.Add(d.Name);
            }

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            string path = comboBox1.Text + comboBox2.Text + "\\" + txtname.Text;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
                MessageBox.Show("Directer has been created");
            }
            else
            {
                MessageBox.Show("Directer Alread Exists");
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            Form1 f2 = new Form1();
            this.Hide();
            f2.Show();

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
