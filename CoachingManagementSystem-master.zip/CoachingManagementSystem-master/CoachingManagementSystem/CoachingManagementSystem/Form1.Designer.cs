﻿namespace CoachingManagementSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuThinButton26 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuGradientPanel3 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuThinButton210 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton29 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton28 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton25 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuGradientPanel4 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuGradientPanel6 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuGradientPanel7 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuGradientPanel8 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.CoursePanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuGradientPanel9 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuThinButton221 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton220 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.GirdView2 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuMetroTextbox4 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuMetroTextbox5 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuThinButton217 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton218 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton219 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.GirdView1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuMetroTextbox3 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuMetroTextbox2 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuThinButton214 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton213 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton212 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Girdview = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuMetroTextbox1 = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.bunifuThinButton24 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuThinButton216 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuThinButton211 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.bunifuDatepicker1 = new Bunifu.Framework.UI.BunifuDatepicker();
            this.bunifuGradientPanel5 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.bunifuCheckbox8 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label15 = new System.Windows.Forms.Label();
            this.bunifuCheckbox9 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label16 = new System.Windows.Forms.Label();
            this.bunifuCheckbox10 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.bunifuCheckbox11 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label19 = new System.Windows.Forms.Label();
            this.bunifuCheckbox12 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label20 = new System.Windows.Forms.Label();
            this.bunifuCheckbox13 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label21 = new System.Windows.Forms.Label();
            this.bunifuCheckbox14 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.bunifuMaterialTextbox9 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox10 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox11 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox12 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox13 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox14 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox15 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox16 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label23 = new System.Windows.Forms.Label();
            this.bunifuCheckbox17 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox18 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.bunifuCheckbox5 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label8 = new System.Windows.Forms.Label();
            this.bunifuCheckbox6 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label9 = new System.Windows.Forms.Label();
            this.bunifuCheckbox7 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.bunifuCheckbox4 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label4 = new System.Windows.Forms.Label();
            this.bunifuCheckbox3 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label3 = new System.Windows.Forms.Label();
            this.bunifuCheckbox2 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label2 = new System.Windows.Forms.Label();
            this.bunifuThinButton27 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCheckbox1 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuMaterialTextbox7 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox6 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox5 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox4 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox3 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox2 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label28 = new System.Windows.Forms.Label();
            this.bunifuCheckbox15 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox16 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.label29 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.bunifuThinButton215 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuGradientPanel2.SuspendLayout();
            this.bunifuGradientPanel3.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            this.bunifuGradientPanel4.SuspendLayout();
            this.bunifuGradientPanel6.SuspendLayout();
            this.bunifuGradientPanel7.SuspendLayout();
            this.bunifuGradientPanel8.SuspendLayout();
            this.CoursePanel.SuspendLayout();
            this.bunifuGradientPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GirdView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GirdView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Girdview)).BeginInit();
            this.bunifuGradientPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuThinButton26);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.Black;
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.Black;
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(1050, 99);
            this.bunifuGradientPanel2.TabIndex = 0;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Monotype Corsiva", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(280, 63);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(386, 39);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "The Name Which You Can Trust";
            // 
            // bunifuThinButton26
            // 
            this.bunifuThinButton26.ActiveBorderThickness = 1;
            this.bunifuThinButton26.ActiveCornerRadius = 20;
            this.bunifuThinButton26.ActiveFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton26.ActiveForecolor = System.Drawing.Color.Transparent;
            this.bunifuThinButton26.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton26.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton26.BackgroundImage")));
            this.bunifuThinButton26.ButtonText = "Exit";
            this.bunifuThinButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton26.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton26.IdleBorderThickness = 1;
            this.bunifuThinButton26.IdleCornerRadius = 20;
            this.bunifuThinButton26.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton26.IdleForecolor = System.Drawing.Color.Red;
            this.bunifuThinButton26.IdleLineColor = System.Drawing.Color.Red;
            this.bunifuThinButton26.Location = new System.Drawing.Point(940, 28);
            this.bunifuThinButton26.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton26.Name = "bunifuThinButton26";
            this.bunifuThinButton26.Size = new System.Drawing.Size(94, 41);
            this.bunifuThinButton26.TabIndex = 1;
            this.bunifuThinButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton26.Click += new System.EventHandler(this.bunifuThinButton26_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Monotype Corsiva", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(27, 26);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(292, 39);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Pacific Coaching System";
            // 
            // bunifuGradientPanel3
            // 
            this.bunifuGradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel3.BackgroundImage")));
            this.bunifuGradientPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton210);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton29);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton28);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton25);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton23);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton22);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuThinButton21);
            this.bunifuGradientPanel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.bunifuGradientPanel3.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel3.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel3.GradientTopLeft = System.Drawing.Color.Black;
            this.bunifuGradientPanel3.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel3.Location = new System.Drawing.Point(0, 99);
            this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
            this.bunifuGradientPanel3.Quality = 10;
            this.bunifuGradientPanel3.Size = new System.Drawing.Size(200, 553);
            this.bunifuGradientPanel3.TabIndex = 1;
            // 
            // bunifuThinButton210
            // 
            this.bunifuThinButton210.ActiveBorderThickness = 1;
            this.bunifuThinButton210.ActiveCornerRadius = 20;
            this.bunifuThinButton210.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton210.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton210.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton210.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton210.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton210.BackgroundImage")));
            this.bunifuThinButton210.ButtonText = "Student";
            this.bunifuThinButton210.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton210.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton210.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton210.IdleBorderThickness = 1;
            this.bunifuThinButton210.IdleCornerRadius = 20;
            this.bunifuThinButton210.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton210.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton210.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton210.Location = new System.Drawing.Point(14, 404);
            this.bunifuThinButton210.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton210.Name = "bunifuThinButton210";
            this.bunifuThinButton210.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton210.TabIndex = 7;
            this.bunifuThinButton210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton210.Click += new System.EventHandler(this.bunifuThinButton210_Click);
            // 
            // bunifuThinButton29
            // 
            this.bunifuThinButton29.ActiveBorderThickness = 1;
            this.bunifuThinButton29.ActiveCornerRadius = 20;
            this.bunifuThinButton29.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton29.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton29.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton29.BackgroundImage")));
            this.bunifuThinButton29.ButtonText = "Trainer";
            this.bunifuThinButton29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton29.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton29.IdleBorderThickness = 1;
            this.bunifuThinButton29.IdleCornerRadius = 20;
            this.bunifuThinButton29.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton29.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton29.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton29.Location = new System.Drawing.Point(10, 344);
            this.bunifuThinButton29.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton29.Name = "bunifuThinButton29";
            this.bunifuThinButton29.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton29.TabIndex = 6;
            this.bunifuThinButton29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton29.Click += new System.EventHandler(this.bunifuThinButton29_Click);
            // 
            // bunifuThinButton28
            // 
            this.bunifuThinButton28.ActiveBorderThickness = 1;
            this.bunifuThinButton28.ActiveCornerRadius = 20;
            this.bunifuThinButton28.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton28.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton28.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton28.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton28.BackgroundImage")));
            this.bunifuThinButton28.ButtonText = "Courses";
            this.bunifuThinButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton28.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton28.IdleBorderThickness = 1;
            this.bunifuThinButton28.IdleCornerRadius = 20;
            this.bunifuThinButton28.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton28.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton28.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton28.Location = new System.Drawing.Point(10, 285);
            this.bunifuThinButton28.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton28.Name = "bunifuThinButton28";
            this.bunifuThinButton28.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton28.TabIndex = 5;
            this.bunifuThinButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton28.Click += new System.EventHandler(this.bunifuThinButton28_Click);
            // 
            // bunifuThinButton25
            // 
            this.bunifuThinButton25.ActiveBorderThickness = 1;
            this.bunifuThinButton25.ActiveCornerRadius = 20;
            this.bunifuThinButton25.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton25.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton25.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton25.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton25.BackgroundImage")));
            this.bunifuThinButton25.ButtonText = "Batch";
            this.bunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton25.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton25.IdleBorderThickness = 1;
            this.bunifuThinButton25.IdleCornerRadius = 20;
            this.bunifuThinButton25.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton25.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton25.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton25.Location = new System.Drawing.Point(10, 225);
            this.bunifuThinButton25.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton25.Name = "bunifuThinButton25";
            this.bunifuThinButton25.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton25.TabIndex = 4;
            this.bunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton25.Click += new System.EventHandler(this.bunifuThinButton25_Click);
            // 
            // bunifuThinButton23
            // 
            this.bunifuThinButton23.ActiveBorderThickness = 1;
            this.bunifuThinButton23.ActiveCornerRadius = 20;
            this.bunifuThinButton23.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton23.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton23.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton23.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton23.BackgroundImage")));
            this.bunifuThinButton23.ButtonText = "Payment";
            this.bunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton23.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton23.IdleBorderThickness = 1;
            this.bunifuThinButton23.IdleCornerRadius = 20;
            this.bunifuThinButton23.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton23.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton23.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton23.Location = new System.Drawing.Point(12, 164);
            this.bunifuThinButton23.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton23.Name = "bunifuThinButton23";
            this.bunifuThinButton23.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton23.TabIndex = 2;
            this.bunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton23.Click += new System.EventHandler(this.bunifuThinButton23_Click);
            // 
            // bunifuThinButton22
            // 
            this.bunifuThinButton22.ActiveBorderThickness = 1;
            this.bunifuThinButton22.ActiveCornerRadius = 20;
            this.bunifuThinButton22.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton22.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton22.BackgroundImage")));
            this.bunifuThinButton22.ButtonText = "Register";
            this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton22.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton22.IdleBorderThickness = 1;
            this.bunifuThinButton22.IdleCornerRadius = 20;
            this.bunifuThinButton22.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton22.Location = new System.Drawing.Point(12, 99);
            this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton22.Name = "bunifuThinButton22";
            this.bunifuThinButton22.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton22.TabIndex = 1;
            this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton22.Click += new System.EventHandler(this.bunifuThinButton22_Click);
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 20;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.Black;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.Black;
            this.bunifuThinButton21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Search";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.Black;
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 20;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.White;
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.White;
            this.bunifuThinButton21.Location = new System.Drawing.Point(14, 35);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton21.TabIndex = 0;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton21.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel4);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel2);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1050, 652);
            this.bunifuGradientPanel1.TabIndex = 0;
            // 
            // bunifuGradientPanel4
            // 
            this.bunifuGradientPanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel4.BackgroundImage")));
            this.bunifuGradientPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel4.Controls.Add(this.bunifuGradientPanel6);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuDatepicker1);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuGradientPanel5);
            this.bunifuGradientPanel4.Controls.Add(this.label11);
            this.bunifuGradientPanel4.Controls.Add(this.label10);
            this.bunifuGradientPanel4.Controls.Add(this.label7);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox5);
            this.bunifuGradientPanel4.Controls.Add(this.label8);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox6);
            this.bunifuGradientPanel4.Controls.Add(this.label9);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox7);
            this.bunifuGradientPanel4.Controls.Add(this.label6);
            this.bunifuGradientPanel4.Controls.Add(this.label5);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox4);
            this.bunifuGradientPanel4.Controls.Add(this.label4);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox3);
            this.bunifuGradientPanel4.Controls.Add(this.label3);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox2);
            this.bunifuGradientPanel4.Controls.Add(this.label2);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuThinButton27);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox1);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel4.Controls.Add(this.label1);
            this.bunifuGradientPanel4.Controls.Add(this.pictureBox2);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox7);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox6);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox5);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox4);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox3);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox2);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuMaterialTextbox1);
            this.bunifuGradientPanel4.Controls.Add(this.label28);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox15);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuCheckbox16);
            this.bunifuGradientPanel4.Controls.Add(this.label29);
            this.bunifuGradientPanel4.Controls.Add(this.label25);
            this.bunifuGradientPanel4.Controls.Add(this.bunifuThinButton215);
            this.bunifuGradientPanel4.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel4.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel4.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel4.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel4.Location = new System.Drawing.Point(199, 98);
            this.bunifuGradientPanel4.Name = "bunifuGradientPanel4";
            this.bunifuGradientPanel4.Quality = 10;
            this.bunifuGradientPanel4.Size = new System.Drawing.Size(851, 554);
            this.bunifuGradientPanel4.TabIndex = 5;
            // 
            // bunifuGradientPanel6
            // 
            this.bunifuGradientPanel6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuGradientPanel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel6.BackgroundImage")));
            this.bunifuGradientPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel6.Controls.Add(this.bunifuGradientPanel7);
            this.bunifuGradientPanel6.Controls.Add(this.textBox13);
            this.bunifuGradientPanel6.Controls.Add(this.textBox12);
            this.bunifuGradientPanel6.Controls.Add(this.textBox11);
            this.bunifuGradientPanel6.Controls.Add(this.textBox10);
            this.bunifuGradientPanel6.Controls.Add(this.textBox9);
            this.bunifuGradientPanel6.Controls.Add(this.textBox8);
            this.bunifuGradientPanel6.Controls.Add(this.textBox7);
            this.bunifuGradientPanel6.Controls.Add(this.textBox6);
            this.bunifuGradientPanel6.Controls.Add(this.textBox5);
            this.bunifuGradientPanel6.Controls.Add(this.textBox4);
            this.bunifuGradientPanel6.Controls.Add(this.textBox3);
            this.bunifuGradientPanel6.Controls.Add(this.textBox2);
            this.bunifuGradientPanel6.Controls.Add(this.textBox1);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel18);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel17);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel16);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel15);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel14);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel13);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel12);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel11);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel10);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel9);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel8);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel7);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel5);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuCustomLabel4);
            this.bunifuGradientPanel6.Controls.Add(this.bunifuThinButton211);
            this.bunifuGradientPanel6.Controls.Add(this.comboBox2);
            this.bunifuGradientPanel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuGradientPanel6.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel6.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel6.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel6.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel6.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel6.Name = "bunifuGradientPanel6";
            this.bunifuGradientPanel6.Quality = 10;
            this.bunifuGradientPanel6.Size = new System.Drawing.Size(851, 551);
            this.bunifuGradientPanel6.TabIndex = 67;
            // 
            // bunifuGradientPanel7
            // 
            this.bunifuGradientPanel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel7.BackgroundImage")));
            this.bunifuGradientPanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel7.Controls.Add(this.bunifuGradientPanel8);
            this.bunifuGradientPanel7.Controls.Add(this.bunifuFlatButton1);
            this.bunifuGradientPanel7.Controls.Add(this.bunifuMetroTextbox1);
            this.bunifuGradientPanel7.Controls.Add(this.bunifuThinButton24);
            this.bunifuGradientPanel7.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel7.Controls.Add(this.bunifuThinButton216);
            this.bunifuGradientPanel7.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel7.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel7.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel7.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel7.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel7.Name = "bunifuGradientPanel7";
            this.bunifuGradientPanel7.Quality = 10;
            this.bunifuGradientPanel7.Size = new System.Drawing.Size(851, 554);
            this.bunifuGradientPanel7.TabIndex = 29;
            // 
            // bunifuGradientPanel8
            // 
            this.bunifuGradientPanel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel8.BackgroundImage")));
            this.bunifuGradientPanel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel8.Controls.Add(this.CoursePanel);
            this.bunifuGradientPanel8.Controls.Add(this.bunifuMetroTextbox3);
            this.bunifuGradientPanel8.Controls.Add(this.bunifuMetroTextbox2);
            this.bunifuGradientPanel8.Controls.Add(this.bunifuThinButton214);
            this.bunifuGradientPanel8.Controls.Add(this.bunifuThinButton213);
            this.bunifuGradientPanel8.Controls.Add(this.bunifuThinButton212);
            this.bunifuGradientPanel8.Controls.Add(this.Girdview);
            this.bunifuGradientPanel8.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel8.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel8.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel8.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel8.Location = new System.Drawing.Point(0, 1);
            this.bunifuGradientPanel8.Name = "bunifuGradientPanel8";
            this.bunifuGradientPanel8.Quality = 10;
            this.bunifuGradientPanel8.Size = new System.Drawing.Size(851, 553);
            this.bunifuGradientPanel8.TabIndex = 3;
            // 
            // CoursePanel
            // 
            this.CoursePanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CoursePanel.BackgroundImage")));
            this.CoursePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CoursePanel.Controls.Add(this.bunifuGradientPanel9);
            this.CoursePanel.Controls.Add(this.bunifuMetroTextbox4);
            this.CoursePanel.Controls.Add(this.bunifuMetroTextbox5);
            this.CoursePanel.Controls.Add(this.bunifuThinButton217);
            this.CoursePanel.Controls.Add(this.bunifuThinButton218);
            this.CoursePanel.Controls.Add(this.bunifuThinButton219);
            this.CoursePanel.Controls.Add(this.GirdView1);
            this.CoursePanel.GradientBottomLeft = System.Drawing.Color.White;
            this.CoursePanel.GradientBottomRight = System.Drawing.Color.White;
            this.CoursePanel.GradientTopLeft = System.Drawing.Color.White;
            this.CoursePanel.GradientTopRight = System.Drawing.Color.White;
            this.CoursePanel.Location = new System.Drawing.Point(0, 0);
            this.CoursePanel.Name = "CoursePanel";
            this.CoursePanel.Quality = 10;
            this.CoursePanel.Size = new System.Drawing.Size(851, 554);
            this.CoursePanel.TabIndex = 6;
            // 
            // bunifuGradientPanel9
            // 
            this.bunifuGradientPanel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel9.BackgroundImage")));
            this.bunifuGradientPanel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel9.Controls.Add(this.button1);
            this.bunifuGradientPanel9.Controls.Add(this.textBox14);
            this.bunifuGradientPanel9.Controls.Add(this.bunifuCustomDataGrid1);
            this.bunifuGradientPanel9.Controls.Add(this.bunifuThinButton221);
            this.bunifuGradientPanel9.Controls.Add(this.bunifuThinButton220);
            this.bunifuGradientPanel9.Controls.Add(this.GirdView2);
            this.bunifuGradientPanel9.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel9.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel9.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel9.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel9.Location = new System.Drawing.Point(0, -1);
            this.bunifuGradientPanel9.Name = "bunifuGradientPanel9";
            this.bunifuGradientPanel9.Quality = 10;
            this.bunifuGradientPanel9.Size = new System.Drawing.Size(851, 555);
            this.bunifuGradientPanel9.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(704, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 28);
            this.button1.TabIndex = 5;
            this.button1.Text = "SEARCH";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(592, 18);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 29);
            this.textBox14.TabIndex = 4;
            this.textBox14.Visible = false;
            // 
            // bunifuCustomDataGrid1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.SeaGreen;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(-222, -144);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(240, 150);
            this.bunifuCustomDataGrid1.TabIndex = 2;
            // 
            // bunifuThinButton221
            // 
            this.bunifuThinButton221.ActiveBorderThickness = 1;
            this.bunifuThinButton221.ActiveCornerRadius = 20;
            this.bunifuThinButton221.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton221.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton221.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton221.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton221.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton221.BackgroundImage")));
            this.bunifuThinButton221.ButtonText = "XII";
            this.bunifuThinButton221.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton221.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton221.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton221.IdleBorderThickness = 1;
            this.bunifuThinButton221.IdleCornerRadius = 20;
            this.bunifuThinButton221.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton221.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton221.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton221.Location = new System.Drawing.Point(334, 284);
            this.bunifuThinButton221.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton221.Name = "bunifuThinButton221";
            this.bunifuThinButton221.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton221.TabIndex = 1;
            this.bunifuThinButton221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton221.Click += new System.EventHandler(this.bunifuThinButton221_Click);
            // 
            // bunifuThinButton220
            // 
            this.bunifuThinButton220.ActiveBorderThickness = 1;
            this.bunifuThinButton220.ActiveCornerRadius = 20;
            this.bunifuThinButton220.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton220.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton220.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton220.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton220.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton220.BackgroundImage")));
            this.bunifuThinButton220.ButtonText = "XI";
            this.bunifuThinButton220.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton220.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton220.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton220.IdleBorderThickness = 1;
            this.bunifuThinButton220.IdleCornerRadius = 20;
            this.bunifuThinButton220.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton220.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton220.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton220.Location = new System.Drawing.Point(331, 220);
            this.bunifuThinButton220.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton220.Name = "bunifuThinButton220";
            this.bunifuThinButton220.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton220.TabIndex = 0;
            this.bunifuThinButton220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton220.Click += new System.EventHandler(this.bunifuThinButton220_Click);
            // 
            // GirdView2
            // 
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.GirdView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.GirdView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GirdView2.BackgroundColor = System.Drawing.Color.White;
            this.GirdView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GirdView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GirdView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.GirdView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GirdView2.DoubleBuffered = true;
            this.GirdView2.EnableHeadersVisualStyles = false;
            this.GirdView2.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GirdView2.HeaderForeColor = System.Drawing.Color.Silver;
            this.GirdView2.Location = new System.Drawing.Point(24, 95);
            this.GirdView2.Name = "GirdView2";
            this.GirdView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GirdView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.GirdView2.Size = new System.Drawing.Size(784, 439);
            this.GirdView2.TabIndex = 3;
            this.GirdView2.Visible = false;
            // 
            // bunifuMetroTextbox4
            // 
            this.bunifuMetroTextbox4.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox4.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox4.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox4.BorderThickness = 3;
            this.bunifuMetroTextbox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMetroTextbox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox4.isPassword = false;
            this.bunifuMetroTextbox4.Location = new System.Drawing.Point(52, 149);
            this.bunifuMetroTextbox4.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox4.Name = "bunifuMetroTextbox4";
            this.bunifuMetroTextbox4.Size = new System.Drawing.Size(370, 44);
            this.bunifuMetroTextbox4.TabIndex = 11;
            this.bunifuMetroTextbox4.Text = "Level";
            this.bunifuMetroTextbox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMetroTextbox5
            // 
            this.bunifuMetroTextbox5.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox5.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox5.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox5.BorderThickness = 3;
            this.bunifuMetroTextbox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMetroTextbox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox5.isPassword = false;
            this.bunifuMetroTextbox5.Location = new System.Drawing.Point(52, 86);
            this.bunifuMetroTextbox5.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox5.Name = "bunifuMetroTextbox5";
            this.bunifuMetroTextbox5.Size = new System.Drawing.Size(370, 44);
            this.bunifuMetroTextbox5.TabIndex = 10;
            this.bunifuMetroTextbox5.Text = "Subject Name";
            this.bunifuMetroTextbox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuThinButton217
            // 
            this.bunifuThinButton217.ActiveBorderThickness = 1;
            this.bunifuThinButton217.ActiveCornerRadius = 20;
            this.bunifuThinButton217.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton217.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton217.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton217.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton217.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton217.BackgroundImage")));
            this.bunifuThinButton217.ButtonText = "ADD";
            this.bunifuThinButton217.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton217.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton217.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton217.IdleBorderThickness = 1;
            this.bunifuThinButton217.IdleCornerRadius = 20;
            this.bunifuThinButton217.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton217.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton217.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton217.Location = new System.Drawing.Point(240, 204);
            this.bunifuThinButton217.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton217.Name = "bunifuThinButton217";
            this.bunifuThinButton217.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton217.TabIndex = 9;
            this.bunifuThinButton217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton217.Click += new System.EventHandler(this.bunifuThinButton217_Click);
            // 
            // bunifuThinButton218
            // 
            this.bunifuThinButton218.ActiveBorderThickness = 1;
            this.bunifuThinButton218.ActiveCornerRadius = 20;
            this.bunifuThinButton218.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton218.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton218.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton218.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton218.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton218.BackgroundImage")));
            this.bunifuThinButton218.ButtonText = "VIEW";
            this.bunifuThinButton218.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton218.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton218.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton218.IdleBorderThickness = 1;
            this.bunifuThinButton218.IdleCornerRadius = 20;
            this.bunifuThinButton218.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton218.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton218.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton218.Location = new System.Drawing.Point(340, 271);
            this.bunifuThinButton218.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton218.Name = "bunifuThinButton218";
            this.bunifuThinButton218.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton218.TabIndex = 8;
            this.bunifuThinButton218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton218.Click += new System.EventHandler(this.bunifuThinButton218_Click);
            // 
            // bunifuThinButton219
            // 
            this.bunifuThinButton219.ActiveBorderThickness = 1;
            this.bunifuThinButton219.ActiveCornerRadius = 20;
            this.bunifuThinButton219.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton219.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton219.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton219.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton219.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton219.BackgroundImage")));
            this.bunifuThinButton219.ButtonText = "ADD";
            this.bunifuThinButton219.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton219.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton219.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton219.IdleBorderThickness = 1;
            this.bunifuThinButton219.IdleCornerRadius = 20;
            this.bunifuThinButton219.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton219.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton219.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton219.Location = new System.Drawing.Point(340, 196);
            this.bunifuThinButton219.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton219.Name = "bunifuThinButton219";
            this.bunifuThinButton219.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton219.TabIndex = 7;
            this.bunifuThinButton219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton219.Click += new System.EventHandler(this.bunifuThinButton219_Click);
            // 
            // GirdView1
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.GirdView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.GirdView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GirdView1.BackgroundColor = System.Drawing.Color.White;
            this.GirdView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GirdView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GirdView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.GirdView1.ColumnHeadersHeight = 60;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GirdView1.DefaultCellStyle = dataGridViewCellStyle7;
            this.GirdView1.DoubleBuffered = true;
            this.GirdView1.EnableHeadersVisualStyles = false;
            this.GirdView1.HeaderBgColor = System.Drawing.Color.Gray;
            this.GirdView1.HeaderForeColor = System.Drawing.Color.Silver;
            this.GirdView1.Location = new System.Drawing.Point(40, 49);
            this.GirdView1.Name = "GirdView1";
            this.GirdView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GirdView1.RowHeadersWidth = 60;
            this.GirdView1.Size = new System.Drawing.Size(737, 399);
            this.GirdView1.TabIndex = 14;
            // 
            // bunifuMetroTextbox3
            // 
            this.bunifuMetroTextbox3.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox3.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox3.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox3.BorderThickness = 3;
            this.bunifuMetroTextbox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMetroTextbox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox3.isPassword = false;
            this.bunifuMetroTextbox3.Location = new System.Drawing.Point(24, 96);
            this.bunifuMetroTextbox3.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox3.Name = "bunifuMetroTextbox3";
            this.bunifuMetroTextbox3.Size = new System.Drawing.Size(370, 44);
            this.bunifuMetroTextbox3.TabIndex = 4;
            this.bunifuMetroTextbox3.Text = "Subject Name";
            this.bunifuMetroTextbox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMetroTextbox2
            // 
            this.bunifuMetroTextbox2.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox2.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox2.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox2.BorderThickness = 3;
            this.bunifuMetroTextbox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMetroTextbox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox2.isPassword = false;
            this.bunifuMetroTextbox2.Location = new System.Drawing.Point(24, 33);
            this.bunifuMetroTextbox2.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox2.Name = "bunifuMetroTextbox2";
            this.bunifuMetroTextbox2.Size = new System.Drawing.Size(370, 44);
            this.bunifuMetroTextbox2.TabIndex = 3;
            this.bunifuMetroTextbox2.Text = "Teacher Name";
            this.bunifuMetroTextbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuThinButton214
            // 
            this.bunifuThinButton214.ActiveBorderThickness = 1;
            this.bunifuThinButton214.ActiveCornerRadius = 20;
            this.bunifuThinButton214.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton214.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton214.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton214.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton214.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton214.BackgroundImage")));
            this.bunifuThinButton214.ButtonText = "ADD";
            this.bunifuThinButton214.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton214.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton214.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton214.IdleBorderThickness = 1;
            this.bunifuThinButton214.IdleCornerRadius = 20;
            this.bunifuThinButton214.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton214.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton214.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton214.Location = new System.Drawing.Point(212, 151);
            this.bunifuThinButton214.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton214.Name = "bunifuThinButton214";
            this.bunifuThinButton214.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton214.TabIndex = 2;
            this.bunifuThinButton214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton214.Click += new System.EventHandler(this.bunifuThinButton214_Click);
            // 
            // bunifuThinButton213
            // 
            this.bunifuThinButton213.ActiveBorderThickness = 1;
            this.bunifuThinButton213.ActiveCornerRadius = 20;
            this.bunifuThinButton213.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton213.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton213.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton213.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton213.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton213.BackgroundImage")));
            this.bunifuThinButton213.ButtonText = "VIEW";
            this.bunifuThinButton213.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton213.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton213.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton213.IdleBorderThickness = 1;
            this.bunifuThinButton213.IdleCornerRadius = 20;
            this.bunifuThinButton213.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton213.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton213.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton213.Location = new System.Drawing.Point(312, 244);
            this.bunifuThinButton213.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton213.Name = "bunifuThinButton213";
            this.bunifuThinButton213.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton213.TabIndex = 1;
            this.bunifuThinButton213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton213.Click += new System.EventHandler(this.bunifuThinButton213_Click);
            // 
            // bunifuThinButton212
            // 
            this.bunifuThinButton212.ActiveBorderThickness = 1;
            this.bunifuThinButton212.ActiveCornerRadius = 20;
            this.bunifuThinButton212.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton212.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton212.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton212.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton212.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton212.BackgroundImage")));
            this.bunifuThinButton212.ButtonText = "ADD";
            this.bunifuThinButton212.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton212.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton212.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton212.IdleBorderThickness = 1;
            this.bunifuThinButton212.IdleCornerRadius = 20;
            this.bunifuThinButton212.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton212.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton212.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton212.Location = new System.Drawing.Point(312, 169);
            this.bunifuThinButton212.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton212.Name = "bunifuThinButton212";
            this.bunifuThinButton212.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton212.TabIndex = 0;
            this.bunifuThinButton212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton212.Click += new System.EventHandler(this.bunifuThinButton212_Click);
            // 
            // Girdview
            // 
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Girdview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
            this.Girdview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Girdview.BackgroundColor = System.Drawing.Color.White;
            this.Girdview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Girdview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Girdview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.Girdview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Girdview.DoubleBuffered = true;
            this.Girdview.EnableHeadersVisualStyles = false;
            this.Girdview.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.Girdview.HeaderBgColor = System.Drawing.Color.Gray;
            this.Girdview.HeaderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Girdview.Location = new System.Drawing.Point(52, 23);
            this.Girdview.Name = "Girdview";
            this.Girdview.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.Girdview.Size = new System.Drawing.Size(708, 488);
            this.Girdview.TabIndex = 5;
            this.Girdview.Visible = false;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "SUBMIT";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(398, 69);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(140, 44);
            this.bunifuFlatButton1.TabIndex = 2;
            this.bunifuFlatButton1.Text = "SUBMIT";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click_1);
            // 
            // bunifuMetroTextbox1
            // 
            this.bunifuMetroTextbox1.BorderColorFocused = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox1.BorderColorMouseHover = System.Drawing.Color.Blue;
            this.bunifuMetroTextbox1.BorderThickness = 3;
            this.bunifuMetroTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMetroTextbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMetroTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMetroTextbox1.isPassword = false;
            this.bunifuMetroTextbox1.Location = new System.Drawing.Point(8, 69);
            this.bunifuMetroTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMetroTextbox1.Name = "bunifuMetroTextbox1";
            this.bunifuMetroTextbox1.Size = new System.Drawing.Size(370, 44);
            this.bunifuMetroTextbox1.TabIndex = 1;
            this.bunifuMetroTextbox1.Text = "Batch_Name";
            this.bunifuMetroTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuThinButton24
            // 
            this.bunifuThinButton24.ActiveBorderThickness = 1;
            this.bunifuThinButton24.ActiveCornerRadius = 20;
            this.bunifuThinButton24.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton24.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton24.BackgroundImage")));
            this.bunifuThinButton24.ButtonText = "Create Batch";
            this.bunifuThinButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton24.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.IdleBorderThickness = 1;
            this.bunifuThinButton24.IdleCornerRadius = 20;
            this.bunifuThinButton24.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton24.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton24.Location = new System.Drawing.Point(345, 226);
            this.bunifuThinButton24.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton24.Name = "bunifuThinButton24";
            this.bunifuThinButton24.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton24.TabIndex = 0;
            this.bunifuThinButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton24.Click += new System.EventHandler(this.bunifuThinButton24_Click);
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator3.LineThickness = 65535;
            this.bunifuSeparator3.Location = new System.Drawing.Point(120, 154);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(639, 35);
            this.bunifuSeparator3.TabIndex = 4;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // bunifuThinButton216
            // 
            this.bunifuThinButton216.ActiveBorderThickness = 1;
            this.bunifuThinButton216.ActiveCornerRadius = 20;
            this.bunifuThinButton216.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton216.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton216.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton216.BackgroundImage")));
            this.bunifuThinButton216.ButtonText = "View Batch";
            this.bunifuThinButton216.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton216.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton216.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.IdleBorderThickness = 1;
            this.bunifuThinButton216.IdleCornerRadius = 20;
            this.bunifuThinButton216.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton216.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton216.Location = new System.Drawing.Point(345, 295);
            this.bunifuThinButton216.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton216.Name = "bunifuThinButton216";
            this.bunifuThinButton216.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton216.TabIndex = 5;
            this.bunifuThinButton216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton216.Click += new System.EventHandler(this.bunifuThinButton216_Click);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(678, 444);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 29);
            this.textBox13.TabIndex = 28;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(678, 387);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 29);
            this.textBox12.TabIndex = 27;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(678, 323);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 29);
            this.textBox11.TabIndex = 26;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(678, 263);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 29);
            this.textBox10.TabIndex = 25;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(678, 194);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 29);
            this.textBox9.TabIndex = 24;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(678, 125);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 29);
            this.textBox8.TabIndex = 23;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(205, 476);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 29);
            this.textBox7.TabIndex = 22;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(205, 415);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 29);
            this.textBox6.TabIndex = 21;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(205, 352);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 29);
            this.textBox5.TabIndex = 20;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(205, 299);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 29);
            this.textBox4.TabIndex = 19;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(205, 235);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 29);
            this.textBox3.TabIndex = 18;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(205, 177);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 29);
            this.textBox2.TabIndex = 17;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(205, 120);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 29);
            this.textBox1.TabIndex = 16;
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(542, 451);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(116, 24);
            this.bunifuCustomLabel18.TabIndex = 15;
            this.bunifuCustomLabel18.Text = "DECEMBER";
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(542, 390);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(119, 24);
            this.bunifuCustomLabel17.TabIndex = 14;
            this.bunifuCustomLabel17.Text = "NOVEMBER";
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(542, 327);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(103, 24);
            this.bunifuCustomLabel16.TabIndex = 13;
            this.bunifuCustomLabel16.Text = "OCTOBER";
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(542, 270);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(126, 24);
            this.bunifuCustomLabel15.TabIndex = 12;
            this.bunifuCustomLabel15.Text = "SEPTEMBER";
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(542, 203);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(87, 24);
            this.bunifuCustomLabel14.TabIndex = 11;
            this.bunifuCustomLabel14.Text = "AUGUST";
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(542, 128);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(54, 24);
            this.bunifuCustomLabel13.TabIndex = 10;
            this.bunifuCustomLabel13.Text = "JULY";
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(35, 483);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(59, 24);
            this.bunifuCustomLabel12.TabIndex = 9;
            this.bunifuCustomLabel12.Text = "JUNE";
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(38, 422);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(51, 24);
            this.bunifuCustomLabel11.TabIndex = 8;
            this.bunifuCustomLabel11.Text = "MAY";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(38, 359);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(62, 24);
            this.bunifuCustomLabel10.TabIndex = 7;
            this.bunifuCustomLabel10.Text = "APRIL";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(38, 303);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(79, 24);
            this.bunifuCustomLabel9.TabIndex = 6;
            this.bunifuCustomLabel9.Text = "MARCH";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(34, 240);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(111, 24);
            this.bunifuCustomLabel8.TabIndex = 5;
            this.bunifuCustomLabel8.Text = "FEBRUARY";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(38, 180);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(97, 24);
            this.bunifuCustomLabel7.TabIndex = 4;
            this.bunifuCustomLabel7.Text = "JANUARY";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(35, 120);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(137, 24);
            this.bunifuCustomLabel5.TabIndex = 2;
            this.bunifuCustomLabel5.Text = "Admission Fee";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(34, 61);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(70, 24);
            this.bunifuCustomLabel4.TabIndex = 0;
            this.bunifuCustomLabel4.Text = "Search";
            // 
            // bunifuThinButton211
            // 
            this.bunifuThinButton211.ActiveBorderThickness = 1;
            this.bunifuThinButton211.ActiveCornerRadius = 20;
            this.bunifuThinButton211.ActiveFillColor = System.Drawing.Color.Black;
            this.bunifuThinButton211.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton211.ActiveLineColor = System.Drawing.Color.Red;
            this.bunifuThinButton211.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuThinButton211.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton211.BackgroundImage")));
            this.bunifuThinButton211.ButtonText = "SUBMIT";
            this.bunifuThinButton211.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton211.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton211.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton211.IdleBorderThickness = 1;
            this.bunifuThinButton211.IdleCornerRadius = 20;
            this.bunifuThinButton211.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton211.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton211.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton211.Location = new System.Drawing.Point(331, 483);
            this.bunifuThinButton211.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton211.Name = "bunifuThinButton211";
            this.bunifuThinButton211.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton211.TabIndex = 30;
            this.bunifuThinButton211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton211.Click += new System.EventHandler(this.bunifuThinButton211_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(125, 53);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(133, 32);
            this.comboBox2.TabIndex = 68;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // bunifuDatepicker1
            // 
            this.bunifuDatepicker1.BackColor = System.Drawing.Color.DarkGray;
            this.bunifuDatepicker1.BorderRadius = 0;
            this.bunifuDatepicker1.ForeColor = System.Drawing.Color.White;
            this.bunifuDatepicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.bunifuDatepicker1.FormatCustom = null;
            this.bunifuDatepicker1.Location = new System.Drawing.Point(28, 457);
            this.bunifuDatepicker1.Name = "bunifuDatepicker1";
            this.bunifuDatepicker1.Size = new System.Drawing.Size(611, 36);
            this.bunifuDatepicker1.TabIndex = 74;
            this.bunifuDatepicker1.Value = new System.DateTime(2018, 5, 31, 4, 22, 26, 989);
            // 
            // bunifuGradientPanel5
            // 
            this.bunifuGradientPanel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel5.BackgroundImage")));
            this.bunifuGradientPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel5.Controls.Add(this.comboBox1);
            this.bunifuGradientPanel5.Controls.Add(this.label24);
            this.bunifuGradientPanel5.Controls.Add(this.label13);
            this.bunifuGradientPanel5.Controls.Add(this.label14);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox8);
            this.bunifuGradientPanel5.Controls.Add(this.label15);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox9);
            this.bunifuGradientPanel5.Controls.Add(this.label16);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox10);
            this.bunifuGradientPanel5.Controls.Add(this.label17);
            this.bunifuGradientPanel5.Controls.Add(this.label18);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox11);
            this.bunifuGradientPanel5.Controls.Add(this.label19);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox12);
            this.bunifuGradientPanel5.Controls.Add(this.label20);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox13);
            this.bunifuGradientPanel5.Controls.Add(this.label21);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox14);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel5.Controls.Add(this.label22);
            this.bunifuGradientPanel5.Controls.Add(this.pictureBox3);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox9);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox10);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox11);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox12);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox13);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox14);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox15);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuMaterialTextbox16);
            this.bunifuGradientPanel5.Controls.Add(this.label23);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox17);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuCheckbox18);
            this.bunifuGradientPanel5.Controls.Add(this.label12);
            this.bunifuGradientPanel5.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel5.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel5.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel5.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel5.Location = new System.Drawing.Point(0, 1);
            this.bunifuGradientPanel5.Name = "bunifuGradientPanel5";
            this.bunifuGradientPanel5.Quality = 10;
            this.bunifuGradientPanel5.Size = new System.Drawing.Size(851, 553);
            this.bunifuGradientPanel5.TabIndex = 30;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(104, 76);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 67;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(20, 515);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 24);
            this.label24.TabIndex = 63;
            this.label24.Text = "Class";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(24, 74);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 20);
            this.label13.TabIndex = 57;
            this.label13.Text = "Form No.";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(700, 493);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(140, 20);
            this.label14.TabIndex = 56;
            this.label14.Text = "Computer Science";
            // 
            // bunifuCheckbox8
            // 
            this.bunifuCheckbox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox8.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox8.Checked = false;
            this.bunifuCheckbox8.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox8.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox8.Location = new System.Drawing.Point(672, 494);
            this.bunifuCheckbox8.Name = "bunifuCheckbox8";
            this.bunifuCheckbox8.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox8.TabIndex = 55;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(700, 461);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 20);
            this.label15.TabIndex = 54;
            this.label15.Text = "Chemistry";
            // 
            // bunifuCheckbox9
            // 
            this.bunifuCheckbox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox9.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox9.Checked = false;
            this.bunifuCheckbox9.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox9.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox9.Location = new System.Drawing.Point(672, 462);
            this.bunifuCheckbox9.Name = "bunifuCheckbox9";
            this.bunifuCheckbox9.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox9.TabIndex = 53;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(700, 430);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 20);
            this.label16.TabIndex = 52;
            this.label16.Text = "Physics";
            // 
            // bunifuCheckbox10
            // 
            this.bunifuCheckbox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox10.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox10.Checked = false;
            this.bunifuCheckbox10.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox10.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox10.Location = new System.Drawing.Point(672, 431);
            this.bunifuCheckbox10.Name = "bunifuCheckbox10";
            this.bunifuCheckbox10.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox10.TabIndex = 51;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(700, 403);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 24);
            this.label17.TabIndex = 50;
            this.label17.Text = "Practicles";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(697, 366);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(140, 20);
            this.label18.TabIndex = 49;
            this.label18.Text = "Computer Science";
            // 
            // bunifuCheckbox11
            // 
            this.bunifuCheckbox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox11.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox11.Checked = false;
            this.bunifuCheckbox11.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox11.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox11.Location = new System.Drawing.Point(669, 367);
            this.bunifuCheckbox11.Name = "bunifuCheckbox11";
            this.bunifuCheckbox11.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox11.TabIndex = 48;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(697, 334);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 20);
            this.label19.TabIndex = 47;
            this.label19.Text = "Chemistry";
            // 
            // bunifuCheckbox12
            // 
            this.bunifuCheckbox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox12.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox12.Checked = false;
            this.bunifuCheckbox12.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox12.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox12.Location = new System.Drawing.Point(669, 335);
            this.bunifuCheckbox12.Name = "bunifuCheckbox12";
            this.bunifuCheckbox12.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox12.TabIndex = 46;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(697, 303);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 20);
            this.label20.TabIndex = 45;
            this.label20.Text = "Physics";
            // 
            // bunifuCheckbox13
            // 
            this.bunifuCheckbox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox13.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox13.Checked = false;
            this.bunifuCheckbox13.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox13.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox13.Location = new System.Drawing.Point(669, 304);
            this.bunifuCheckbox13.Name = "bunifuCheckbox13";
            this.bunifuCheckbox13.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox13.TabIndex = 44;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(700, 269);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(100, 20);
            this.label21.TabIndex = 43;
            this.label21.Text = "Mathematics";
            // 
            // bunifuCheckbox14
            // 
            this.bunifuCheckbox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox14.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox14.Checked = false;
            this.bunifuCheckbox14.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox14.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox14.Location = new System.Drawing.Point(669, 270);
            this.bunifuCheckbox14.Name = "bunifuCheckbox14";
            this.bunifuCheckbox14.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox14.TabIndex = 41;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(646, 226);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(17, 318);
            this.bunifuSeparator2.TabIndex = 40;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(700, 240);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 24);
            this.label22.TabIndex = 39;
            this.label22.Text = "Faculty";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(672, 18);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(136, 141);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            // 
            // bunifuMaterialTextbox9
            // 
            this.bunifuMaterialTextbox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox9.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox9.HintText = "";
            this.bunifuMaterialTextbox9.isPassword = false;
            this.bunifuMaterialTextbox9.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox9.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox9.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox9.LineThickness = 3;
            this.bunifuMaterialTextbox9.Location = new System.Drawing.Point(24, 457);
            this.bunifuMaterialTextbox9.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox9.Name = "bunifuMaterialTextbox9";
            this.bunifuMaterialTextbox9.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox9.TabIndex = 37;
            this.bunifuMaterialTextbox9.Text = "Date of Birth";
            this.bunifuMaterialTextbox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox10
            // 
            this.bunifuMaterialTextbox10.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox10.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox10.HintText = "";
            this.bunifuMaterialTextbox10.isPassword = false;
            this.bunifuMaterialTextbox10.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox10.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox10.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox10.LineThickness = 3;
            this.bunifuMaterialTextbox10.Location = new System.Drawing.Point(24, 410);
            this.bunifuMaterialTextbox10.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox10.Name = "bunifuMaterialTextbox10";
            this.bunifuMaterialTextbox10.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox10.TabIndex = 36;
            this.bunifuMaterialTextbox10.Text = "Gender";
            this.bunifuMaterialTextbox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox11
            // 
            this.bunifuMaterialTextbox11.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox11.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox11.HintText = "";
            this.bunifuMaterialTextbox11.isPassword = false;
            this.bunifuMaterialTextbox11.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox11.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox11.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox11.LineThickness = 3;
            this.bunifuMaterialTextbox11.Location = new System.Drawing.Point(24, 359);
            this.bunifuMaterialTextbox11.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox11.Name = "bunifuMaterialTextbox11";
            this.bunifuMaterialTextbox11.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox11.TabIndex = 35;
            this.bunifuMaterialTextbox11.Text = "Email";
            this.bunifuMaterialTextbox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox12
            // 
            this.bunifuMaterialTextbox12.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox12.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox12.HintText = "";
            this.bunifuMaterialTextbox12.isPassword = false;
            this.bunifuMaterialTextbox12.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox12.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox12.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox12.LineThickness = 3;
            this.bunifuMaterialTextbox12.Location = new System.Drawing.Point(24, 304);
            this.bunifuMaterialTextbox12.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox12.Name = "bunifuMaterialTextbox12";
            this.bunifuMaterialTextbox12.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox12.TabIndex = 34;
            this.bunifuMaterialTextbox12.Text = "Mobile Number";
            this.bunifuMaterialTextbox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox13
            // 
            this.bunifuMaterialTextbox13.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox13.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox13.HintText = "";
            this.bunifuMaterialTextbox13.isPassword = false;
            this.bunifuMaterialTextbox13.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox13.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox13.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox13.LineThickness = 3;
            this.bunifuMaterialTextbox13.Location = new System.Drawing.Point(24, 252);
            this.bunifuMaterialTextbox13.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox13.Name = "bunifuMaterialTextbox13";
            this.bunifuMaterialTextbox13.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox13.TabIndex = 33;
            this.bunifuMaterialTextbox13.Text = "Religion";
            this.bunifuMaterialTextbox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox14
            // 
            this.bunifuMaterialTextbox14.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox14.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox14.HintText = "";
            this.bunifuMaterialTextbox14.isPassword = false;
            this.bunifuMaterialTextbox14.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox14.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox14.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox14.LineThickness = 3;
            this.bunifuMaterialTextbox14.Location = new System.Drawing.Point(24, 205);
            this.bunifuMaterialTextbox14.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox14.Name = "bunifuMaterialTextbox14";
            this.bunifuMaterialTextbox14.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox14.TabIndex = 32;
            this.bunifuMaterialTextbox14.Text = "Address";
            this.bunifuMaterialTextbox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox15
            // 
            this.bunifuMaterialTextbox15.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox15.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox15.HintText = "";
            this.bunifuMaterialTextbox15.isPassword = false;
            this.bunifuMaterialTextbox15.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox15.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox15.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox15.LineThickness = 3;
            this.bunifuMaterialTextbox15.Location = new System.Drawing.Point(24, 160);
            this.bunifuMaterialTextbox15.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox15.Name = "bunifuMaterialTextbox15";
            this.bunifuMaterialTextbox15.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox15.TabIndex = 31;
            this.bunifuMaterialTextbox15.Text = "Father Name";
            this.bunifuMaterialTextbox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuMaterialTextbox16
            // 
            this.bunifuMaterialTextbox16.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox16.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox16.HintText = "";
            this.bunifuMaterialTextbox16.isPassword = false;
            this.bunifuMaterialTextbox16.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox16.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox16.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox16.LineThickness = 3;
            this.bunifuMaterialTextbox16.Location = new System.Drawing.Point(24, 112);
            this.bunifuMaterialTextbox16.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox16.Name = "bunifuMaterialTextbox16";
            this.bunifuMaterialTextbox16.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox16.TabIndex = 30;
            this.bunifuMaterialTextbox16.Text = "Name";
            this.bunifuMaterialTextbox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(245, 515);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 24);
            this.label23.TabIndex = 62;
            this.label23.Text = "XII";
            // 
            // bunifuCheckbox17
            // 
            this.bunifuCheckbox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox17.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox17.Checked = false;
            this.bunifuCheckbox17.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox17.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox17.Location = new System.Drawing.Point(219, 514);
            this.bunifuCheckbox17.Name = "bunifuCheckbox17";
            this.bunifuCheckbox17.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox17.TabIndex = 66;
            // 
            // bunifuCheckbox18
            // 
            this.bunifuCheckbox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox18.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox18.Checked = false;
            this.bunifuCheckbox18.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox18.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox18.Location = new System.Drawing.Point(121, 514);
            this.bunifuCheckbox18.Name = "bunifuCheckbox18";
            this.bunifuCheckbox18.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox18.TabIndex = 64;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(147, 514);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 24);
            this.label12.TabIndex = 60;
            this.label12.Text = "XI";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(122, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 20);
            this.label11.TabIndex = 29;
            this.label11.Text = "Number";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(24, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 20);
            this.label10.TabIndex = 28;
            this.label10.Text = "Form No.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(700, 493);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "Computer Science";
            // 
            // bunifuCheckbox5
            // 
            this.bunifuCheckbox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox5.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox5.Checked = false;
            this.bunifuCheckbox5.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox5.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox5.Location = new System.Drawing.Point(672, 494);
            this.bunifuCheckbox5.Name = "bunifuCheckbox5";
            this.bunifuCheckbox5.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox5.TabIndex = 26;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(700, 461);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 20);
            this.label8.TabIndex = 25;
            this.label8.Text = "Chemistry";
            // 
            // bunifuCheckbox6
            // 
            this.bunifuCheckbox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox6.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox6.Checked = false;
            this.bunifuCheckbox6.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox6.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox6.Location = new System.Drawing.Point(672, 462);
            this.bunifuCheckbox6.Name = "bunifuCheckbox6";
            this.bunifuCheckbox6.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox6.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(700, 430);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Physics";
            // 
            // bunifuCheckbox7
            // 
            this.bunifuCheckbox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox7.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox7.Checked = false;
            this.bunifuCheckbox7.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox7.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox7.Location = new System.Drawing.Point(672, 431);
            this.bunifuCheckbox7.Name = "bunifuCheckbox7";
            this.bunifuCheckbox7.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox7.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(700, 403);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 24);
            this.label6.TabIndex = 21;
            this.label6.Text = "Practicles";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(697, 366);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "Computer Science";
            // 
            // bunifuCheckbox4
            // 
            this.bunifuCheckbox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox4.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox4.Checked = false;
            this.bunifuCheckbox4.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox4.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox4.Location = new System.Drawing.Point(669, 367);
            this.bunifuCheckbox4.Name = "bunifuCheckbox4";
            this.bunifuCheckbox4.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox4.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(697, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Chemistry";
            // 
            // bunifuCheckbox3
            // 
            this.bunifuCheckbox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox3.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox3.Checked = false;
            this.bunifuCheckbox3.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox3.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox3.Location = new System.Drawing.Point(669, 335);
            this.bunifuCheckbox3.Name = "bunifuCheckbox3";
            this.bunifuCheckbox3.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox3.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(697, 303);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "Physics";
            // 
            // bunifuCheckbox2
            // 
            this.bunifuCheckbox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox2.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox2.Checked = false;
            this.bunifuCheckbox2.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox2.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox2.Location = new System.Drawing.Point(669, 304);
            this.bunifuCheckbox2.Name = "bunifuCheckbox2";
            this.bunifuCheckbox2.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox2.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(700, 269);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 14;
            this.label2.Text = "Mathematics";
            // 
            // bunifuThinButton27
            // 
            this.bunifuThinButton27.ActiveBorderThickness = 1;
            this.bunifuThinButton27.ActiveCornerRadius = 20;
            this.bunifuThinButton27.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton27.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton27.BackgroundImage")));
            this.bunifuThinButton27.ButtonText = "Upload Image";
            this.bunifuThinButton27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton27.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.IdleBorderThickness = 1;
            this.bunifuThinButton27.IdleCornerRadius = 20;
            this.bunifuThinButton27.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton27.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton27.Location = new System.Drawing.Point(654, 165);
            this.bunifuThinButton27.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton27.Name = "bunifuThinButton27";
            this.bunifuThinButton27.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton27.TabIndex = 13;
            this.bunifuThinButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton27.Click += new System.EventHandler(this.bunifuThinButton27_Click);
            // 
            // bunifuCheckbox1
            // 
            this.bunifuCheckbox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox1.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox1.Checked = false;
            this.bunifuCheckbox1.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox1.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox1.Location = new System.Drawing.Point(669, 270);
            this.bunifuCheckbox1.Name = "bunifuCheckbox1";
            this.bunifuCheckbox1.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox1.TabIndex = 12;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(646, 226);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(17, 318);
            this.bunifuSeparator1.TabIndex = 11;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(700, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Faculty";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(672, 18);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(136, 141);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuMaterialTextbox7
            // 
            this.bunifuMaterialTextbox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox7.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox7.HintText = "";
            this.bunifuMaterialTextbox7.isPassword = false;
            this.bunifuMaterialTextbox7.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox7.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox7.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox7.LineThickness = 3;
            this.bunifuMaterialTextbox7.Location = new System.Drawing.Point(24, 410);
            this.bunifuMaterialTextbox7.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox7.Name = "bunifuMaterialTextbox7";
            this.bunifuMaterialTextbox7.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox7.TabIndex = 6;
            this.bunifuMaterialTextbox7.Text = "Gender";
            this.bunifuMaterialTextbox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox7.Enter += new System.EventHandler(this.bunifuMaterialTextbox7_Enter);
            this.bunifuMaterialTextbox7.Leave += new System.EventHandler(this.bunifuMaterialTextbox7_Leave);
            // 
            // bunifuMaterialTextbox6
            // 
            this.bunifuMaterialTextbox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox6.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox6.HintText = "";
            this.bunifuMaterialTextbox6.isPassword = false;
            this.bunifuMaterialTextbox6.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox6.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox6.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox6.LineThickness = 3;
            this.bunifuMaterialTextbox6.Location = new System.Drawing.Point(24, 359);
            this.bunifuMaterialTextbox6.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox6.Name = "bunifuMaterialTextbox6";
            this.bunifuMaterialTextbox6.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox6.TabIndex = 5;
            this.bunifuMaterialTextbox6.Text = "Email";
            this.bunifuMaterialTextbox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox6.Enter += new System.EventHandler(this.bunifuMaterialTextbox6_Enter);
            this.bunifuMaterialTextbox6.Leave += new System.EventHandler(this.bunifuMaterialTextbox6_Leave);
            // 
            // bunifuMaterialTextbox5
            // 
            this.bunifuMaterialTextbox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox5.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox5.HintText = "";
            this.bunifuMaterialTextbox5.isPassword = false;
            this.bunifuMaterialTextbox5.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox5.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox5.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox5.LineThickness = 3;
            this.bunifuMaterialTextbox5.Location = new System.Drawing.Point(24, 304);
            this.bunifuMaterialTextbox5.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox5.Name = "bunifuMaterialTextbox5";
            this.bunifuMaterialTextbox5.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox5.TabIndex = 4;
            this.bunifuMaterialTextbox5.Text = "Mobile Number";
            this.bunifuMaterialTextbox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox5.Enter += new System.EventHandler(this.bunifuMaterialTextbox5_Enter);
            this.bunifuMaterialTextbox5.Leave += new System.EventHandler(this.bunifuMaterialTextbox5_Leave);
            // 
            // bunifuMaterialTextbox4
            // 
            this.bunifuMaterialTextbox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox4.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox4.HintText = "";
            this.bunifuMaterialTextbox4.isPassword = false;
            this.bunifuMaterialTextbox4.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox4.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox4.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox4.LineThickness = 3;
            this.bunifuMaterialTextbox4.Location = new System.Drawing.Point(24, 252);
            this.bunifuMaterialTextbox4.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox4.Name = "bunifuMaterialTextbox4";
            this.bunifuMaterialTextbox4.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox4.TabIndex = 3;
            this.bunifuMaterialTextbox4.Text = "Religion";
            this.bunifuMaterialTextbox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox4.Enter += new System.EventHandler(this.bunifuMaterialTextbox4_Enter);
            this.bunifuMaterialTextbox4.Leave += new System.EventHandler(this.bunifuMaterialTextbox4_Leave);
            // 
            // bunifuMaterialTextbox3
            // 
            this.bunifuMaterialTextbox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox3.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox3.HintText = "";
            this.bunifuMaterialTextbox3.isPassword = false;
            this.bunifuMaterialTextbox3.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox3.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox3.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox3.LineThickness = 3;
            this.bunifuMaterialTextbox3.Location = new System.Drawing.Point(24, 205);
            this.bunifuMaterialTextbox3.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox3.Name = "bunifuMaterialTextbox3";
            this.bunifuMaterialTextbox3.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox3.TabIndex = 2;
            this.bunifuMaterialTextbox3.Text = "Address";
            this.bunifuMaterialTextbox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox3.Enter += new System.EventHandler(this.bunifuMaterialTextbox3_Enter);
            this.bunifuMaterialTextbox3.Leave += new System.EventHandler(this.bunifuMaterialTextbox3_Leave);
            // 
            // bunifuMaterialTextbox2
            // 
            this.bunifuMaterialTextbox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox2.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox2.HintText = "";
            this.bunifuMaterialTextbox2.isPassword = false;
            this.bunifuMaterialTextbox2.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox2.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox2.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox2.LineThickness = 3;
            this.bunifuMaterialTextbox2.Location = new System.Drawing.Point(24, 160);
            this.bunifuMaterialTextbox2.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox2.Name = "bunifuMaterialTextbox2";
            this.bunifuMaterialTextbox2.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox2.TabIndex = 1;
            this.bunifuMaterialTextbox2.Text = "Father Name";
            this.bunifuMaterialTextbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox2.Enter += new System.EventHandler(this.bunifuMaterialTextbox2_Enter);
            this.bunifuMaterialTextbox2.Leave += new System.EventHandler(this.bunifuMaterialTextbox2_Leave);
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox1.HintText = "";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineThickness = 3;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(24, 112);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(615, 33);
            this.bunifuMaterialTextbox1.TabIndex = 0;
            this.bunifuMaterialTextbox1.Text = "Name";
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuMaterialTextbox1.Enter += new System.EventHandler(this.bunifuMaterialTextbox1_Enter);
            this.bunifuMaterialTextbox1.Leave += new System.EventHandler(this.bunifuMaterialTextbox1_Leave);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(240, 515);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 24);
            this.label28.TabIndex = 70;
            this.label28.Text = "XII";
            // 
            // bunifuCheckbox15
            // 
            this.bunifuCheckbox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox15.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox15.Checked = false;
            this.bunifuCheckbox15.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox15.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox15.Location = new System.Drawing.Point(214, 514);
            this.bunifuCheckbox15.Name = "bunifuCheckbox15";
            this.bunifuCheckbox15.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox15.TabIndex = 72;
            // 
            // bunifuCheckbox16
            // 
            this.bunifuCheckbox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox16.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox16.Checked = false;
            this.bunifuCheckbox16.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.bunifuCheckbox16.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox16.Location = new System.Drawing.Point(117, 514);
            this.bunifuCheckbox16.Name = "bunifuCheckbox16";
            this.bunifuCheckbox16.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox16.TabIndex = 71;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(142, 514);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 24);
            this.label29.TabIndex = 69;
            this.label29.Text = "XI";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(24, 515);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 24);
            this.label25.TabIndex = 68;
            this.label25.Text = "Class";
            // 
            // bunifuThinButton215
            // 
            this.bunifuThinButton215.ActiveBorderThickness = 1;
            this.bunifuThinButton215.ActiveCornerRadius = 20;
            this.bunifuThinButton215.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton215.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton215.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton215.BackgroundImage")));
            this.bunifuThinButton215.ButtonText = "SUBMIT";
            this.bunifuThinButton215.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton215.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton215.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.IdleBorderThickness = 1;
            this.bunifuThinButton215.IdleCornerRadius = 20;
            this.bunifuThinButton215.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton215.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton215.Location = new System.Drawing.Point(446, 503);
            this.bunifuThinButton215.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton215.Name = "bunifuThinButton215";
            this.bunifuThinButton215.Size = new System.Drawing.Size(181, 41);
            this.bunifuThinButton215.TabIndex = 73;
            this.bunifuThinButton215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton215.Click += new System.EventHandler(this.bunifuThinButton215_Click);
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Monotype Corsiva", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(483, 294);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(292, 39);
            this.bunifuCustomLabel3.TabIndex = 3;
            this.bunifuCustomLabel3.Text = "Pacific Coaching System";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::CoachingManagementSystem.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(374, 263);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(530, 269);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 652);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "Form1";
            this.Text = "PACIFIC COACHING SYSTEM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.bunifuGradientPanel2.ResumeLayout(false);
            this.bunifuGradientPanel2.PerformLayout();
            this.bunifuGradientPanel3.ResumeLayout(false);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.bunifuGradientPanel4.ResumeLayout(false);
            this.bunifuGradientPanel4.PerformLayout();
            this.bunifuGradientPanel6.ResumeLayout(false);
            this.bunifuGradientPanel6.PerformLayout();
            this.bunifuGradientPanel7.ResumeLayout(false);
            this.bunifuGradientPanel8.ResumeLayout(false);
            this.CoursePanel.ResumeLayout(false);
            this.bunifuGradientPanel9.ResumeLayout(false);
            this.bunifuGradientPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GirdView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GirdView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Girdview)).EndInit();
            this.bunifuGradientPanel5.ResumeLayout(false);
            this.bunifuGradientPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton26;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel3;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton25;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton23;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton28;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton210;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton29;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        public System.Windows.Forms.PictureBox pictureBox1;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel4;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox7;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox6;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox5;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox4;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox3;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox2;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox1;
        public Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox pictureBox2;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton27;
        public System.Windows.Forms.Label label5;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox4;
        public System.Windows.Forms.Label label4;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox3;
        public System.Windows.Forms.Label label3;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox2;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label7;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox5;
        public System.Windows.Forms.Label label8;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox6;
        public System.Windows.Forms.Label label9;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox7;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label10;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel5;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label14;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox8;
        public System.Windows.Forms.Label label15;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox9;
        public System.Windows.Forms.Label label16;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox10;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Label label18;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox11;
        public System.Windows.Forms.Label label19;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox12;
        public System.Windows.Forms.Label label20;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox13;
        public System.Windows.Forms.Label label21;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox14;
        public Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.PictureBox pictureBox3;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox9;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox10;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox11;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox12;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox13;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox14;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox15;
        public Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox16;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label25;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox17;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox18;
        public System.Windows.Forms.Label label28;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox15;
        public Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox16;
        public System.Windows.Forms.Label label29;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel6;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        public Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        public System.Windows.Forms.TextBox textBox13;
        public System.Windows.Forms.TextBox textBox12;
        public System.Windows.Forms.TextBox textBox11;
        public System.Windows.Forms.TextBox textBox10;
        public System.Windows.Forms.TextBox textBox9;
        public System.Windows.Forms.TextBox textBox8;
        public System.Windows.Forms.TextBox textBox7;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox4;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox1;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel7;
        public Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        public Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox1;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton24;
        public Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel8;
        public Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox3;
        public Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox2;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton214;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton213;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton212;
        public Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton215;
        public Bunifu.Framework.UI.BunifuDatepicker bunifuDatepicker1;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton211;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton216;
        public Bunifu.Framework.UI.BunifuCustomDataGrid Girdview;
        private Bunifu.Framework.UI.BunifuGradientPanel CoursePanel;
        public Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox4;
        public Bunifu.Framework.UI.BunifuMetroTextbox bunifuMetroTextbox5;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton217;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton218;
        public Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton219;
        public Bunifu.Framework.UI.BunifuCustomDataGrid GirdView1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel9;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton221;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton220;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        public Bunifu.Framework.UI.BunifuCustomDataGrid GirdView2;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.TextBox textBox14;
        public System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.ComboBox comboBox2;


    }
}

