﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

namespace booking
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=BOOKING;Integrated Security=True");

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            this.Hide();
            f.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM  login WHERE User_name='" + textBox3.Text + "'and Password='" + textBox4.Text + "'", con);
            con.Open();

            DataTable d = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(d);

            if (d.Rows.Count == 1)
            {

                MessageBox.Show("login  sucessfully");
                this.Hide();
                Form3 f = new Form3();
                f.Show();
            }
            else
            {
                MessageBox.Show("login not sucessfully");
            }
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }
    }
}
