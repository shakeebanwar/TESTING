﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
namespace booking
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=haier-pc;Initial Catalog=BOOKING;Integrated Security=True");
        public int id;
        private void view()
        {

            SqlCommand cmd = new SqlCommand("select * from movie", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();



        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form3 F = new Form3();
            this.Hide();
            F.Show();

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("insert into movie values('" + textBox1.Text + "','" + dateTimePicker1.Text + "','" + textBox3.Text + "','" + richTextBox1.Text + "')", con);

                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("record insert");
                con.Close();
                view();
                textBox1.Text = "";
                dateTimePicker1.Text = "";
                textBox3.Text = "";
                richTextBox1.Text = "";
              

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            view();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

           
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            dateTimePicker1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

            richTextBox1.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
          

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("update movie set movie_name='" + textBox1.Text+ "',release_date='" + dateTimePicker1.Text + "' , language='" + textBox3.Text + "' , tag_line='" + richTextBox1.Text + "'where id=@id", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ID", this.id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record update");
                view();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (id > 0)
                {


                    SqlCommand cmd = new SqlCommand("Delete from movie where id=@id", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@id", this.id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record delete");
                    view();
                    textBox1.Text = "";
                    dateTimePicker1.Text = "";
                    textBox3.Text = "";
                    richTextBox1.Text = "";

                }
                else
                {
                    MessageBox.Show("select row first");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
